__version__ = "0.1.2"
__author__ = "Emil Artemev"
__email__ = "jordanman1300@gmail.com"
__description__ = 'SPyderSQL is a modern ORM framework for SQL database in Python.'
__url__ = 'https://github.com/RealWakeArmilus/SPyderSQL'